# Metronic - Bootstrap 5 HTML, React, Angular, VueJS & Laravel Admin Dashboard Theme

- The React version can be downloaded online from [Metronic Downloads](//devs.keenthemes.com/metronic)

- For a quick start please check [Online documentation page](//preview.keenthemes.com/metronic8/react/docs/)

- The offline documentation is available within the theme [Offline documentation page](//localhost:5011/)

- For any theme related questions please contact our [Theme Support](//keenthemes.com/support/)

- Using Metronic in a new project or for a new client? Purchase a new license https://1.envato.market/EA4JP or watch https://youtu.be/HJ3RNhoI24A to find out more information about licenses.

- Stay tuned for updates via [Twitter](//www.twitter.com/keenthemes) and [Instagram](//www.instagram.com/keenthemes) and
  check our marketplace for more amazing products: [Keenthemes Marketplace](//keenthemes.com/)

Happy coding with Metronic!
